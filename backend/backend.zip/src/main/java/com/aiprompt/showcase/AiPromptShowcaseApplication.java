package com.aiprompt.showcase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiPromptShowcaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiPromptShowcaseApplication.class, args);
	}

}
